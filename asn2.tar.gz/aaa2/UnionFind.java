/*
 * Jiacheng Yu
 * 250799525
 */


public class UnionFind {
	//the size of each sets
	private int[] rank;
	//point to the parent of i
	private int[] parent;
	//number of sets in total
	private int numSets;
	//final lock
	private boolean finalLock = false;
	
	//constructor: constructs an union-find data type with n elements, 1, 2,... ,n
	public UnionFind(int n){
		if(n > 0){
			this.numSets = n;
			rank = new int[n];
			parent = new int[n];
			for(int i = 0; i < n; i++){
				parent[i] = i;
				rank[i] = i;	
			}
		}
	}
	
	//creates a new set whose only member (and thus representative) is i
	public void make_set(int i){
		//check if final lock is on
		if(finalLock == false){
			parent[i] = i;
			rank[i] = 0;
			numSets++;
		}
	}
	
	//unites the dynamic sets that contains i and j, respectively, into a new set that is the union of these two sets
	public void union_set(int i,int j){
		if(finalLock == false){
			Link(find_set(i), find_set(j));
		}
	}
	
	//helper method for union two sets
	public void Link(int i,int j){
		if(rank[i] > rank[j]){
			parent[j] = i;
		}
		else if(rank[i] < rank[j]){
			parent[i] = j;
		}
		else if(i != j){
			parent[j] = i;
			rank[i] = rank[i] + i;
		}
	}
	
	//returns the representative of the set containing i
	public int find_set(int i){
		if(i != parent[i]){
			parent[i] = find_set(parent[i]);
		}
		return (parent[i]);
	}
	
	//returns the total number of current sets
	public int final_sets(){
		finalLock = true;
		return numSets;
	}
}
